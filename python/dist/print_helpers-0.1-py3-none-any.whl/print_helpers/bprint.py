def upper_print(message):
    print(message.upper())


if __name__ == '__main__':
    print("Hello little child.")
    upper_print("You have run bprint as a script")
    print("That seems great. Goodnight.")

