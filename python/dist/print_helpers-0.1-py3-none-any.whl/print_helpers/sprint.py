def tacky_print(message):
    print(message.upper())


if __name__ == '__main__':
    print("Hello again.")
    tacky_print("You have run sprint as a script")
    print("That seems great. Goodnight.")
